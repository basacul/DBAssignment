function parseData() {
    var dataBlock = JSON.parse( all_data );
    console.log(dataBlock);
    var hashtag = [], date = [], counter = 0, counter_array = [];
    var selectBox = document.getElementById( "selectHashtag" );
    var getHashtag = selectBox.options[ selectBox.selectedIndex ].text;
    var getData = { date, counter };

    for ( j = 0; j < 9; j++ ) {
        for ( i = 0; i < dataBlock.length; i++ ) {
            var month = dataBlock[ i ].month;
            if ( ( dataBlock[ i ].hashtag === getHashtag ) && ( ( j+1 ) === month ) ) {
                counter++;
            }
        }
        date.push( [ j, '0' + j + '.2016'] );
        counter_array.push( [ j, counter ] );
        counter = 0;
    }
    getData.date = date;
    getData.counter = counter_array;
    console.log(getData);
    return( getData )
}
