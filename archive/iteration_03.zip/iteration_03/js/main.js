$(document).ready(function() {
  console.log('main js implemented');
  main();
  function main() {
      var parse;
    console.log('main starts');
    parseData();
    getCloseParameter();
  }

})

function parseData() {
  parse = hashtags.array;
  // console.log(parse);
  // console.log(hashtags);
  // console.log(parse.length);
}

function getCloseParameter() {
    inSamePost();
    hasNeighborsFromOthers();

    function inSamePost() {
        for ( var i = 0; i < parse.length; i++ ) {
            var hashtag = parse[ i ];
            hashtag.hasNeighbor = false;

            if ( i === parse.length-1 ) {
                if ( valOfHashtag === parse[ i-1 ].idcontent ) {
                    hashtag.hasDirectNeighbor = true;
                }
            }
            else {
                for ( var j = i+1; j < parse.length; j++ ) {
                    var nextHashtag = parse[ j ];
                    var valOfHashtag = hashtag.idcontent;
                    var valOfNextHashtag = nextHashtag.idcontent;
                    if ( i > 1 ) {
                        if ( valOfHashtag === parse[ i-1 ].idcontent ) {
                            hashtag.hasDirectNeighbor = true;
                        }
                    }
                    if ( valOfHashtag === valOfNextHashtag ) {
                        hashtag.hasDirectNeighbor = true;
                    }
                }
            }

            // console.log(hashtag);
            // console.log(parse);
        }
    }

    function hasNeighborsFromOthers() {
        console.log(parse);
    }
}
