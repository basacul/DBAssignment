# -*- coding: utf-8 -*-
import ast
import json
import sjo
import random
import clearLine

freadPath = "hashtags.json"
fread = open(freadPath, 'r')

newNodes = "sigma_data_time.json"
fnodes = open(newNodes, 'w')
fnodes.write('{\n\t\"nodes\": [\n')
fnodes.close()
fnodes = open(newNodes, 'a')

i = j = k = m = n = p = z = 0


content = fread.readlines()
content = [x.strip() for x in content]
hashtags = [];

for element in content:
    # element[i] = element[i].replace('\'', '')
    array_element = element.split(",")
    # print(array_element)
    hashtagID = array_element[0]
    hashtagID = hashtagID.replace('{"id":', '')
    hashtagContendID = array_element[1]
    hashtagContendID = hashtagContendID.replace('"idcontent":', '')
    hashtagContent = array_element[2]
    hashtagContent = hashtagContent.replace('"hashtag":', '')
    hashtagContent = hashtagContent.replace('}', '')
    array_hashtag = [hashtagID, hashtagContendID, hashtagContent]
    hashtags.append(array_hashtag)

for el in hashtags:
    elID = el[0]
    elCID = el[1]
    elCon = el[2]
    z = 0
    y = 0
    for isNotAlone in hashtags:
        cmpCon = isNotAlone[2]
        cmpCID = isNotAlone[1]
        if cmpCon == elCon:
            if elCID != cmpCID:
                z = z+1
    for nN in hashtags:
        cmpCID = nN[1]
        cmpID = nN[0]
        if cmpCID == elCID:
            if cmpID != elID:
                y = y+1
    if p % 2 == 0:
        n = -0.759
        o = 2**0.9
        o = o * -1
        o = o + (int(elID)/100)
    else:
        n = 0.759
        o = 2
        o = o - (int(elID)/100)
    if y == 0:
        if z == 0:
            # print('yes00')
            fnodes.write(
                sjo.nodeId + str(i) +
                sjo.nodeLabel + elCon +
                sjo.nodeX + "{:.9f}".format(i**0.8) +
                sjo.nodeY +"{:.9f}".format(i**0.5) +
                sjo.nodeSize +str(1) +
                sjo.endNode )
        if z != 0:
            # print('no01')
            fnodes.write(
                sjo.nodeId + str(i) +
                sjo.nodeLabel + elCon +
                sjo.nodeX + "{:.9f}".format(i*0.8) +
                sjo.nodeY + str(z*20) +
                sjo.nodeSize + str(z) +
                sjo.endNode )
    if y != 0:
        if z == 0:
            fnodes.write(
                sjo.nodeId + str(i) +
                sjo.nodeLabel + elCon +
                sjo.nodeX + "{:.9f}".format(i**0.8) +
                sjo.nodeY +"{:.9f}".format(i**0.55) +
                sjo.nodeSize + str(1) +
                sjo.endNode )
        if z != 0:
            fnodes.write(
                sjo.nodeId + str(i) +
                sjo.nodeLabel + elCon +
                sjo.nodeX + "{:.9f}".format(i*0.8) +
                sjo.nodeY + str(z*20) +
                sjo.nodeSize + str(z) +
                sjo.endNode )
    i = i+1
    p = p+1

clearLine.clearLastLine( fnodes, newNodes)
fnodes = open(newNodes, 'a')
fnodes.write('\t\t}\n],\n\t\"edges\": [\n')

for el in hashtags:
    elID = el[0]
    elCID = el[1]
    elCon = el[2]
    m = 0
    for key in hashtags:
        keyCID = key[1]
        if elCID == keyCID:
            fnodes.write(
                sjo.edgeId + str(k) +
                sjo.edgeSource + str(j) +
                sjo.edgeTarget + str(m) +
                sjo.endEdge)
            k = k+1
        m = m+1
    j = j+1

clearLine.clearLastLine( fnodes, newNodes)
fnodes = open(newNodes, 'a')
fnodes.write('\t\t}\n\t]\n}')

fnodes.close()
fread.close()

print( 'FILE IS PREPARED FOR SIGMA.JS' )
