def clearLastLine( fnodes, newNodes ):
    fnodes.close()
    fnodes = open(newNodes, 'r')
    lines = fnodes.readlines()
    fnodes.close()
    fnodes = open(newNodes, 'w')
    fnodes.writelines([item for item in lines[:-1]])
    fnodes.close()
    return
