import java.util.ArrayList;

/**
 * Implementierung genommen und angepasst von:
 * http://www.dataonfocus.com/k-means-clustering-java-code/
 *
 */
public class Point {

	private double x = 0;
	private double y = 0;
	private int cluster_number = 0;
	private ArrayList<Double> doubleList = new ArrayList<Double>();

	public Point(ArrayList<Double> doubleList) {
		for (double d : doubleList) {
			this.doubleList.add(d);
		}
	}

	public void toPoint(ArrayList<Double> tfIDFVector) {
		for (int i = 0; i < tfIDFVector.size(); i++) {
			tfIDFVector.get(i);
		}
	}

	public ArrayList<Double> getDoubleList() {
		return this.doubleList;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getX() {
		return this.x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getY() {
		return this.y;
	}

	public void setCluster(int n) {
		this.cluster_number = n;
	}

	public int getCluster() {
		return this.cluster_number;
	}

	// Calculates the distance between two points.
	protected static double distance(Point point, Point centroid) {
		ArrayList<Double> pointDoubleList = point.getDoubleList();
		ArrayList<Double> centroidDoubleList = centroid.getDoubleList();
		double pow = 0;
		for (int i = 0; i < pointDoubleList.size(); i++) {
			double dif = centroidDoubleList.get(i) - pointDoubleList.get(i);
			if (dif > 0.0) {
				pow += dif;
			}
		}
		return Math.sqrt(pow);
	}

	/*
	 * // Creates random point protected static Point createRandomPoint(int min,
	 * int max) { Random r = new Random(); double x = min + (max - min) *
	 * r.nextDouble(); double y = min + (max - min) * r.nextDouble(); return new
	 * Point(x, y); }
	 * 
	 * protected static List<Point> createRandomPoints(int min, int max, int
	 * number) { List<Point> points = new ArrayList<Point>(number); for (int i =
	 * 0; i < number; i++) { points.add(createRandomPoint(min, max)); } return
	 * points; }
	 */

	public String toString() {
		String string = "(";
		for (double d : getDoubleList()) {
			string = string + d;
			string = string + ",";
		}
		string = string + ")";
		return string;
	}
}