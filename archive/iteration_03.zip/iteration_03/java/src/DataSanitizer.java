import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Stack;

/**
 * 
 * @author Maximilian Valenza
 *
 */

public class DataSanitizer {
	private static final String FILESYSTEM_SEPARATOR = FileSystems.getDefault().getSeparator();
	private static final String OUTPUT_FILE_PREFIX = "sanitized_";
	private static final String similarHashTagFileName = "similarHashTag";

	private static final String postgresDBName = "postgres";
	private static final String postgresName = "postgres";
	private static final String postgresPass = "admin";

	private static HashMap<String, HashTag> hashTagMap = new HashMap<String, HashTag>();
	private static ArrayList<HashTag> hashTagList = new ArrayList<HashTag>();
	private static ArrayList<String> linkList = new ArrayList<String>();
	private static HashMap<String, Double> dictionary = new HashMap<String, Double>();

	// Primary key for the Tweet and as Foreign Key for all others
	private static int i = 0;
	// Primary key for the Hashtag table
	private static int hashtagID = 0;
	// Primary key for the Link table
	private static int linkID = 0;

	/*
	 * tested the number of errors thrown along the population of the database
	 * election which was used to test and count the number of erroneous entries
	 * along the sanitization process or as a simple feedback tool for further
	 * investigation
	 */
	private static int error = 0;

	public static void main(String[] args) throws Exception {
		// Input/Output files
		File csvFile = Paths.get(args[0]).toAbsolutePath().toFile();
		File outFile = new File(
				csvFile.getParentFile() + FILESYSTEM_SEPARATOR + OUTPUT_FILE_PREFIX + csvFile.getName());

		// Filereader/-writer
		Scanner scanner = new Scanner(csvFile);
		FileWriter fileWriter = new FileWriter(outFile);
		BufferedWriter buffWriter = new BufferedWriter(fileWriter);

		Connection connection = connectToDb();
		Statement statement = connection.createStatement();

		if (args.length > 1 && args[1].equals("similarHashTags")) {
			analyzeDBHashTagsForSimilarity(statement);
		} else {
			loadCSVFileIntoDB(scanner, buffWriter, statement);
		}
		// close connections to the database
		try {
			statement.close();
			connection.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Failure");
		}

		// Close I/O
		buffWriter.close();
		fileWriter.close();
		scanner.close();
	}

	/**
	 * 
	 */
	private static Connection connectToDb() {
		Connection connection = null;
		try {
			Class.forName("org.postgresql.Driver");

			connection = DriverManager.getConnection("jdbc:postgresql://[::1]:5432/" + postgresDBName, postgresName,
					postgresPass);

			System.out.println("Successfully established the connection to the database.");
		} catch (Exception e) {
			System.out.println("Error during connection to the database: " + e.getMessage());
		}
		return connection;
	}

	/**
	 * @param statement
	 * @throws SQLException
	 * @throws ParseException
	 * @throws IOException
	 */
	private static void analyzeDBHashTagsForSimilarity(Statement statement)
			throws SQLException, ParseException, IOException {
		DictionaryManager dictionaryManager = new DictionaryManager();
		HashTagManager hashTagManager = new HashTagManager();

		linkList = dictionaryManager.generateLinkListFromDB(statement);
		hashTagMap = hashTagManager.generateHashTagMapFromDB(statement, linkList);
		hashTagList = hashTagManager.getHashTagList(hashTagMap);

		dictionary = dictionaryManager.generateDictionary(hashTagList, linkList);

		ArrayList<String> vocabularyVector = dictionaryManager.convertDictionaryToVocabularyVector(dictionary);
		hashTagList = hashTagManager.calculateTFForAllHashTags(hashTagList, vocabularyVector);
		hashTagList = hashTagManager.normalizeTFVectorForAllHashTags(hashTagList);
		ArrayList<Double> iDFVocabularyVector = hashTagManager.calculateIDFForVocabularyVector(vocabularyVector,
				dictionary, hashTagList);
		hashTagList = hashTagManager.calculateCosSimForAllHashTags(hashTagList);
		hashTagList = hashTagManager.createPointsForAllHashTags(hashTagList);

		KMeans kmeans = new KMeans();
		kmeans.init(hashTagList);
		kmeans.calculate();

		try (BufferedWriter buffWriter = new BufferedWriter(new FileWriter(new File(similarHashTagFileName)))) {
			for (HashTag hashTag : hashTagList) {
				buffWriter.write("Cosine similarity for hashtag " + hashTag.getHashTagName() + ":\n");
				Iterator<Entry<String, Double>> hashTagCosSimMapIterator = hashTag.getCosSimHashTagMap().entrySet()
						.iterator();
				while (hashTagCosSimMapIterator.hasNext()) {
					Entry<String, Double> hashTagCoSim = hashTagCosSimMapIterator.next();
					buffWriter.write(hashTagCoSim.getKey() + ": " + hashTagCoSim.getValue() + "\n");
				}
				buffWriter.write("\n");
			}
		}

		/*
		 * for (int i = 0; i < vocabularyVector.size(); i++) {
		 * buffWriter.write(vocabularyVector.get(i) + ": " +
		 * iDFVocabularyVector.get(i) + "\n"); } buffWriter.close();
		 */

		Iterator<Entry<String, Double>> dicIt = dictionary.entrySet().iterator();
		while (dicIt.hasNext()) {
			Entry<String, Double> entry = dicIt.next();
			String word = entry.getKey();
			double amount = entry.getValue();
			if (amount > 10.0) {
				System.out.println(word + ": " + (int) amount);
			}
		}

		System.out.println("Done.");
	}

	/**
	 * @param scanner
	 * @param buffWriter
	 * @param statement
	 * @throws IOException
	 */
	private static void loadCSVFileIntoDB(Scanner scanner, BufferedWriter buffWriter, Statement statement)
			throws IOException {
		CSVParser csvParser = new CSVParserImpl();
		// Skip the first line (column names).
		if (scanner.hasNext()) {
			scanner.nextLine();
		}

		// Go through each line and retrieve the necessary values to populate
		// each table in the database.
		while (scanner.hasNext()) {
			List<String> line = csvParser.parseLine(scanner.nextLine());

			// Check whether the line is correct, if not skip it.
			if (!verifyLine(line)) {
				continue;
			}

			// Clean part of the data and populates the tables in the database.
			populateDB(line, statement);

			writeSQLValuesToFile(line, buffWriter);
		}
		System.out.println("Number of corrupted lines : " + error);
	}

	/**
	 * @param line
	 * @throws IOException
	 */
	private static void writeSQLValuesToFile(List<String> line, BufferedWriter buffWriter) throws IOException {
		// Append "("
		line.set(0, "(" + line.get(0));
		// Quote "text" to prevent comma inside it from interfering with SQL
		line.set(1, "\"" + line.get(1) + "\"");
		// Prepend ")"
		line.set(line.size() - 1, line.get(line.size() - 1) + ")");

		SQLPrinter<List<String>> sqlPrinter = new SQLPrinter<List<String>>();
		sqlPrinter.setUnformattedStringList(line);
		String sqlValue = sqlPrinter.toString();

		if (!sqlValue.isEmpty()) {
			buffWriter.write(sqlValue + "\n");
		}
	}

	private static void populateDB(List<String> line, Statement statement) {
		String plainText = line.get(1);

		for (int c = 0; c < plainText.length(); c++) {
			if (plainText.charAt(c) == '\'') {
				plainText = plainText.substring(0, c) + ' ' + plainText.substring(c + 1);
			}
		}

		// for retrieving the hashtags and links and working on plainText
		ArrayList<String> hashtags = getHashTagsFromString(plainText);
		ArrayList<String> links = getLinksFromString(plainText);

		// Time string is cleaned by replacing 'T' with ' '
		line.set(4, (line.get(4).substring(0, 10) + " " + line.get(4).substring(11, line.get(4).length() - 1)));

		doDBInserts(line, statement, plainText, hashtags, links);

		// increments the id, which will be set automatically for each Tweet
		// entry
		// but i is used to decrease computation through jdbc
		++i;

		// clear arraylist hashtags
		hashtags.clear();
		links.clear();
	}

	/**
	 * @param plainText
	 * @return
	 */
	private static ArrayList<String> getLinksFromString(String plainText) {
		ArrayList<String> links = new ArrayList<String>();
		// link retrieved go to next iteration
		boolean breakLoop = false;
		int diff = 0;

		// retrieve the links and dynamically update length condition in outer
		// for loop
		for (int w = 0; w < plainText.length(); w++) {
			diff = w + 3;
			if (diff < plainText.length() && plainText.charAt(w) == 'h' && plainText.charAt(w + 1) == 't'
					&& plainText.charAt(w + 2) == 't' && plainText.charAt(w + 3) == 'p') {
				for (int e = w; e < plainText.length() && !breakLoop; e++) {
					if (plainText.charAt(e) == ' ' || plainText.charAt(e) == ',' || plainText.charAt(e) == '\''
							|| e + 1 == plainText.length()) {
						links.add(plainText.substring(w, e));
						w = e;
						breakLoop = true;
					}
				}
			}
			breakLoop = false;
		}
		return links;
	}

	/**
	 * @param plainText
	 * @return
	 */
	private static ArrayList<String> getHashTagsFromString(String plainText) {
		ArrayList<String> hashtags = new ArrayList<String>();
		// if hashtag was retrieved go to next iteration
		boolean breakLoop = false;
		// retrieve the hash and dynamically update length condition in outer
		// for loop
		for (int w = 0; w < plainText.length(); w++) {
			if (plainText.charAt(w) == '#') {
				for (int e = w; e < plainText.length() && !breakLoop; e++) {
					if (plainText.charAt(e) == ' ' || plainText.charAt(e) == ',' || plainText.charAt(e) == '\''
							|| e + 1 == plainText.length()) {
						// System.out.println("hashtags");
						hashtags.add(plainText.substring(w, e));
						w = e;
						breakLoop = true;
					}
				}
			}
			breakLoop = false;
		}
		return hashtags;
	}

	/**
	 * @param line
	 * @param statement
	 * @param plainText
	 * @param hashtags
	 * @param links
	 */
	private static void doDBInserts(List<String> line, Statement statement, String plainText,
			ArrayList<String> hashtags, ArrayList<String> links) {
		// populate the tables in the database
		try {
			statement.executeUpdate(
					"INSERT INTO Tweet (id, created, favouriteCount, sourceUrl, quoteStatus, truncated, retweetCount, handle) VALUES ('"
							+ i + "','" + line.get(4) + "', '" + line.get(8) + "', '" + line.get(9) + "', "
							+ line.get(6) + ", " + line.get(10) + ", " + line.get(7) + ", '" + line.get(0) + "')");
			statement.executeUpdate("INSERT INTO Content (id, idTweet)" + "VALUES ('" + i + "', '" + i + "')");
			statement.executeUpdate("INSERT INTO Text (id, idContent, plaintext) " + "VALUES ('" + i + "','" + i
					+ "', '" + plainText + "')");

			for (int q = 0; q < hashtags.size(); q++) {
				statement.executeUpdate("INSERT INTO Hashtag (id, idContent, hashtag) VALUES ('" + (hashtagID++)
						+ "' , '" + i + "' , '" + hashtags.get(q) + "')");
			}

			for (int q = 0; q < links.size(); q++) {
				statement.executeUpdate("INSERT INTO Link (id, idContent, link) " + "VALUES ('" + (linkID++) + "' , '"
						+ i + "', '" + links.get(q) + "')");
			}

			statement.executeUpdate("INSERT INTO TargetHandle (id, idContent, targetHandle) VALUES ('" + i + "','" + i
					+ "', '" + line.get(0) + "')");
			statement.executeUpdate("INSERT INTO Retweet (id, idTweet, originalHandle) " + "VALUES ( '" + i + "','" + i
					+ "', '" + line.get(3) + "')");
			statement.executeUpdate(
					"INSERT INTO Reply (idTweet, replyHandle) " + "VALUES ('" + i + "', '" + line.get(5) + "')");
		} catch (Exception e) {
			System.out.println("Still unlucky?" + e.getMessage());
			++error;
		}
	}

	private static boolean verifyLine(List<String> line) {
		boolean lineIsCorrect = true;
		// Throw away all lines not containing exactly
		// CSVParserImpl.DEFAULT_SEPARATOR_MAX amount of separators and an even
		// amount of "
		if (line.size() != 11 || !lineTextIsBalanced(line)) {
			lineIsCorrect = false;
		}
		return lineIsCorrect;
	}

	private static boolean lineTextIsBalanced(List<String> line) {
		boolean isBalanced = true;
		String lineText = line.get(1);
		final Stack<Character> stack = new Stack<Character>();

		for (int p = 0; p < lineText.length(); p++) {
			if ('\"' == (lineText.charAt(p))) {
				stack.push(lineText.charAt(p));
			}
		}
		if ((stack.size() % 2) != 0) {
			isBalanced = false;
		}
		return isBalanced;
	}
}