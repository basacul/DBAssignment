import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * 
 */

/**
 * @author Maximilian Valenza
 *
 */
public class HashTag {
	private String hashTagName;
	private HashMap<String, Double> wordOccurrenceMap;
	private ArrayList<Date> dateList;
	private ArrayList<String> similarHashTagNameList;
	private ArrayList<Double> tfVector;
	private ArrayList<Double> tffIDFVector;
	private HashMap<String, Double> cosSimHashTagMap;
	private Point hashTagPoint;

	public HashTag() {
		this.hashTagName = "";
		this.wordOccurrenceMap = new HashMap<String, Double>();
		this.dateList = new ArrayList<Date>();
		this.similarHashTagNameList = new ArrayList<String>();
		this.tfVector = new ArrayList<Double>();
		this.tffIDFVector = new ArrayList<Double>();
		this.cosSimHashTagMap = new HashMap<String, Double>();
		this.hashTagPoint = new Point(new ArrayList<Double>());
	}

	/*
	 * Public methods
	 */
	public String getHashTagName() {
		return hashTagName;
	}

	public void setHashTagName(String hashTag) {
		this.hashTagName = hashTag;
	}

	public HashMap<String, Double> getWordOccurrenceMap() {
		return wordOccurrenceMap;
	}

	public void setWordOccurrenceMap(HashMap<String, Double> wordOccurrenceMap) {
		this.wordOccurrenceMap = wordOccurrenceMap;
	}

	public ArrayList<Date> getDateList() {
		return dateList;
	}

	public void setDateList(ArrayList<Date> dateList) {
		this.dateList = dateList;
	}

	public void addToDateList(Date date) {
		dateList.add(date);
	}

	public void addToWordOccurrenceMap(String wordToAdd) {
		if (wordOccurrenceMap.containsKey(wordToAdd)) {
			wordOccurrenceMap.put(wordToAdd, wordOccurrenceMap.get(wordToAdd) + 1);
		} else {
			wordOccurrenceMap.put(wordToAdd, 1.0);
		}
	}

	public ArrayList<String> getSimilarHashTagNameList() {
		return similarHashTagNameList;
	}

	public void addToSimilarHashTagList(HashTag hashTag) {
		String similarHashTagName = hashTag.getHashTagName();
		similarHashTagName = cleanString(similarHashTagName);
		if (!similarHashTagNameList.contains(similarHashTagName) && !(hashTagName.equals(similarHashTagName))
				&& (!isSubstring(similarHashTagName))) {
			similarHashTagNameList.add(similarHashTagName);
		}
	}

	public ArrayList<Double> getTFVector() {
		return tfVector;
	}

	public void setTFVector(ArrayList<Double> tfVector) {
		this.tfVector = tfVector;
	}

	public ArrayList<Double> getTffIDFVector() {
		return tffIDFVector;
	}

	public void setTffIDFVector(ArrayList<Double> tffIDFVector) {
		this.tffIDFVector = tffIDFVector;
	}

	/**
	 * @return the hashTagPoint
	 */
	public Point getHashTagPoint() {
		return hashTagPoint;
	}

	/**
	 * @param hashTagPoint
	 *            the hashTagPoint to set
	 */
	public void setHashTagPoint(Point hashTagPoint) {
		this.hashTagPoint = hashTagPoint;
	}

	public HashMap<String, Double> getCosSimHashTagMap() {
		return cosSimHashTagMap;
	}

	public void setCosSimHashTagMap(HashMap<String, Double> cosSimHashTagMap) {
		this.cosSimHashTagMap = cosSimHashTagMap;
	}

	public void addToCosSimHashTagMap(String hashTagName, double cosSim) {
		cosSimHashTagMap.put(hashTagName, cosSim);
	}

	/*
	 * Private methods
	 */
	private String cleanString(String string) {
		string = string.replaceAll("[\\.\\^\\:\\,\\;]", "");
		return string;
	}

	private boolean isSubstring(String string) {
		boolean isSubstring = false;
		if (hashTagName.endsWith(string) || string.endsWith(hashTagName)) {
			isSubstring = true;
		}
		return isSubstring;
	}
}
