import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Implementierung genommen und stark angepasst von:
 * http://www.dataonfocus.com/k-means-clustering-java-code/
 *
 */

/*
 * KMeans.java ; Cluster.java ; Point.java
 *
 * Solution implemented by DataOnFocus www.dataonfocus.com 2015
 *
 */

/*
 * KMeans.java ; Cluster.java ; Point.java
 *
 * Solution implemented by DataOnFocus www.dataonfocus.com 2015
 *
 */
public class KMeans {

	private static final String fileName = "cluster.txt";
	// Number of Clusters. This metric should be related to the number of points
	private int NUM_CLUSTERS = 20;
	// Number of Points
	private int NUM_POINTS = 268;
	// Min and Max X and Y
	private static final int MIN_COORDINATE = 0;
	private static final int MAX_COORDINATE = 10;
	private static final int max_iterations = 20;

	private List<Point> points;
	private List<Cluster> clusters;

	public KMeans() {
		this.points = new ArrayList<Point>();
		this.clusters = new ArrayList<Cluster>();
	}

	public static void main(String[] args) {

		KMeans kmeans = new KMeans();
		// kmeans.init();
		kmeans.calculate();
	}

	// Initializes the process
	public void init(ArrayList<HashTag> hashTagList) {
		// Create Points
		// points = Point.createRandomPoints(MIN_COORDINATE, MAX_COORDINATE,
		// NUM_POINTS);

		for (HashTag hashTag : hashTagList) {
			points.add(hashTag.getHashTagPoint());
		}

		Random randomGenerator = new Random();

		// Create Clusters
		// Set Random Centroids
		for (int i = 0; i < NUM_CLUSTERS; i++) {
			int randInt = randomGenerator.nextInt(points.size());
			Cluster cluster = new Cluster(i);
			Point centroid = points.get(randInt);
			cluster.setCentroid(centroid);
			clusters.add(cluster);
		}

		// Print Initial state
		plotClusters();
	}

	private void plotClusters() {
		for (int i = 0; i < NUM_CLUSTERS; i++) {
			Cluster c = clusters.get(i);
			c.plotCluster();
		}
	}

	// The process to calculate the K Means, with iterating method.
	public void calculate() {
		boolean finish = false;
		int iteration = 0;

		// Add in new data, one at a time, recalculating centroids with each new
		// one.
		while (!finish) {
			// Clear cluster state
			clearClusters();

			List<Point> lastCentroids = getCentroids();

			// Assign points to the closer cluster
			assignCluster();

			// Calculate new centroids.
			calculateCentroids();

			iteration++;

			List<Point> currentCentroids = getCentroids();

			// Calculates total distance between new and old Centroids
			double distance = 0;
			for (int i = 0; i < lastCentroids.size(); i++) {
				// distance +=
				// HashTagManager.cosineSimilarity(lastCentroids.get(i).getDoubleList(),
				// currentCentroids.get(i).getDoubleList());
				distance += Point.distance(lastCentroids.get(i), currentCentroids.get(i));
			}
			try (BufferedWriter buffWriter = new BufferedWriter(new FileWriter(new File(fileName), true))) {
				buffWriter.write("#################\n");
				buffWriter.write("Iteration: " + iteration + "\n");
				buffWriter.write("Centroid distances: " + distance + "\n");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("#################");
			System.out.println("Iteration: " + iteration);
			System.out.println("Centroid distances: " + distance);
			plotClusters();

			if (distance == 0 || iteration == max_iterations) {
				finish = true;
			}
		}
	}

	private void clearClusters() {
		for (Cluster cluster : clusters) {
			cluster.clear();
		}
	}

	private List<Point> getCentroids() {
		List<Point> centroids = new ArrayList<Point>(NUM_CLUSTERS);
		for (Cluster cluster : clusters) {
			Point aux = cluster.getCentroid();
			Point point = new Point(aux.getDoubleList());
			centroids.add(point);
		}
		return centroids;
	}

	private void assignCluster() {
		double max = Double.MAX_VALUE;
		double min = max;
		int cluster = 0;
		double distance = 0.0;

		for (Point point : points) {
			min = max;
			for (int i = 0; i < NUM_CLUSTERS; i++) {
				Cluster c = clusters.get(i);
				// distance =
				// HashTagManager.cosineSimilarity(point.getDoubleList(),
				// c.getCentroid().getDoubleList());
				distance = Point.distance(point, c.getCentroid());
				if (distance < min) {
					min = distance;
					cluster = i;
				}
			}
			point.setCluster(cluster);
			clusters.get(cluster).addPoint(point);
		}
	}

	private void calculateCentroids() {
		for (Cluster cluster : clusters) {
			double sumX = 0;
			double sumY = 0;
			List<Point> list = cluster.getPoints();
			int n_points = list.size();

			for (Point point : list) {
				sumX += point.getX();
				sumY += point.getY();
			}

			Point centroid = cluster.getCentroid();
			if (n_points > 0) {
				double newX = sumX / n_points;
				double newY = sumY / n_points;
				centroid.setX(newX);
				centroid.setY(newY);
			}
		}
	}
}