import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementierung genommen und leicht angepasst von:
 * http://www.dataonfocus.com/k-means-clustering-java-code/
 *
 */
public class Cluster {
	private static final String fileName = "cluster.txt";

	public List<Point> points;
	public Point centroid;
	public int id;

	// Creates a new Cluster
	public Cluster(int id) {
		this.id = id;
		this.points = new ArrayList<Point>();
		this.centroid = null;
	}

	public List<Point> getPoints() {
		return points;
	}

	public void addPoint(Point point) {
		points.add(point);
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}

	public Point getCentroid() {
		return centroid;
	}

	public void setCentroid(Point centroid) {
		this.centroid = centroid;
	}

	public int getId() {
		return id;
	}

	public void clear() {
		points.clear();
	}

	public void plotCluster() {
		try (BufferedWriter buffWriter = new BufferedWriter(new FileWriter(new File(fileName), true))) {
			buffWriter.write("[Cluster: " + id + "]");
			buffWriter.write("[Centroid: " + centroid + "]");
			buffWriter.write("[Points: \n");
			for (Point p : points) {
				buffWriter.write(p.toString());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("[Cluster: " + id + "]");
		System.out.println("[Centroid: " + centroid + "]");
		System.out.println("[Points: \n");
		for (Point p : points) {
			System.out.println(p);
		}
		System.out.println("]");
	}

}