import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

/**
 * @author Maximilian Valenza
 *
 */
public class DictionaryManager {
	int WORD_OCCURRENCE_THRESHOLD = 10;

	public DictionaryManager() {
		super();
	}

	public HashMap<String, Double> generateDictionary(ArrayList<HashTag> hashTagList, ArrayList<String> linkList) {
		HashMap<String, Double> dictionary = new HashMap<String, Double>();
		HashMap<String, Double> tempDictionary = new HashMap<String, Double>();

		// Iterate over all HashTags
		for (HashTag hashTag : hashTagList) {
			// Get all words occurring with each HashTag and their amount
			HashMap<String, Double> hashTagWordOccurrenceMap = hashTag.getWordOccurrenceMap();

			Iterator<Entry<String, Double>> hashTagWordOccurrenceMapIterator = hashTagWordOccurrenceMap.entrySet()
					.iterator();
			while (hashTagWordOccurrenceMapIterator.hasNext()) {
				Entry<String, Double> entry = hashTagWordOccurrenceMapIterator.next();

				String key = entry.getKey();
				double value = entry.getValue();
				// Add all words together with their occurrence amount to the
				// dictionary
				if (!(isLink(key, linkList) || isMention(key))) {
					key = cleanString(key);
					key = key.toLowerCase();

					if (!StopWords.isStopword(key)) {
						if (dictionary.containsKey(key)) {
							double currentValue = dictionary.get(key);
							value = value + currentValue;
							dictionary.put(key, value);
						} else {
							dictionary.put(key, value);
						}
					}
				}
			}
		}

		// Iterate over the new dictionary and remove entries with too few
		// occurrences to account for spelling errors
		Iterator<Entry<String, Double>> iter = tempDictionary.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<String, Double> entry = iter.next();
			String key = entry.getKey();
			double value = entry.getValue();
			if (value >= WORD_OCCURRENCE_THRESHOLD) {
				// dictionary.put(key, value);
			}
		}
		return dictionary;
	}

	public ArrayList<String> convertDictionaryToVocabularyVector(HashMap<String, Double> dictionary) {
		ArrayList<String> vocabularyVector = new ArrayList<String>();

		Iterator<String> dictionaryWordIterator = dictionary.keySet().iterator();
		while (dictionaryWordIterator.hasNext()) {
			vocabularyVector.add(dictionaryWordIterator.next());
		}

		return vocabularyVector;
	}

	public ArrayList<String> generateLinkListFromDB(Statement statement) {
		ArrayList<String> linkList = new ArrayList<String>();
		try {
			String query = "SELECT link FROM link";

			ResultSet resSet = statement.executeQuery(query);

			while (resSet.next()) {
				String link = resSet.getString(1);
				linkList.add(link);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return linkList;
	}

	/*
	 * Private methods
	 */
	private String cleanString(String string) {
		string = string.replaceAll("[\\.\\^\\:\\,\\;\\�\\-\\!\\?]", "");
		return string;
	}

	private boolean isMention(String string) {
		boolean isMention = false;
		if (string.startsWith("@")) {
			isMention = true;
		}
		return isMention;
	}

	private boolean isLink(String string, ArrayList<String> linkList) {
		boolean isLink = false;
		if (linkList.contains(string) || string.startsWith("http")) {
			isLink = true;
		}
		return isLink;
	}
}
