import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author Maximilian Valenza
 *
 */
public class HashTagManager {
	public HashTagManager() {
		super();
	}

	/*
	 * Public methods
	 */
	public HashMap<String, HashTag> generateHashTagMapFromDB(Statement statement, ArrayList<String> linkList) {
		HashMap<String, HashTag> hashTagMap = new HashMap<String, HashTag>();
		try {

			String datePattern = "yyyy-MM-dd HH:mm:ss";
			String query = "SELECT hashtag.id, hashtag.idcontent, hashtag.hashtag, text.plaintext, tweet.created" + " "
					+ "FROM hashtag, text, tweet, content" + " "
					+ "WHERE hashtag.idcontent = text.idcontent AND hashtag.idcontent = content.id AND content.idtweet = tweet.id";
			String myquery = "SELECT hashtag.id, hashtag.idcontent, hashtag.hashtag, text.plaintext, tweet.created"
					+ " " + "FROM hashtag, text, tweet, content" + " "
					+ "WHERE hashtag.idcontent = text.idcontent AND hashtag.idcontent = content.id AND content.idtweet = tweet.id";

			// Date format in the database
			DateFormat formatter = new SimpleDateFormat(datePattern);
			ResultSet resSet = statement.executeQuery(query);

			while (resSet.next()) {
				HashTag hashTag = new HashTag();

				// int hashtagid = resSet.getInt(1);
				// int idcontent = resSet.getInt(2);
				String hashTagName = resSet.getString(3);
				hashTagName = cleanString(hashTagName);
				String text = resSet.getString(4);
				String tweetDateString = resSet.getString(5);
				java.util.Date tweetDate = formatter.parse(tweetDateString);

				if (hashTagMap.containsKey(hashTagName)) {
					hashTag = hashTagMap.get(hashTagName);
					for (String wordToAdd : text.split(" ")) {
						if (!(isLink(wordToAdd, linkList) || isMention(wordToAdd))) {
							wordToAdd = cleanString(wordToAdd);
							wordToAdd = wordToAdd.toLowerCase();
							hashTag.addToWordOccurrenceMap(wordToAdd);
						}
					}
					hashTag.addToDateList(tweetDate);
					hashTagMap.put(hashTagName, hashTag);
				} else {
					hashTag.setHashTagName(hashTagName);
					for (String wordToAdd : text.split(" ")) {
						if (!(isLink(wordToAdd, linkList) || isMention(wordToAdd))) {
							wordToAdd = cleanString(wordToAdd);
							wordToAdd = wordToAdd.toLowerCase();
							hashTag.addToWordOccurrenceMap(wordToAdd);
						}
					}
					hashTag.addToDateList(tweetDate);
					hashTagMap.put(hashTagName, hashTag);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return hashTagMap;
	}

	public ArrayList<HashTag> getHashTagList(HashMap<String, HashTag> hashTagMap) {
		ArrayList<HashTag> hashTagList = new ArrayList<HashTag>();
		Iterator<Entry<String, HashTag>> hashTagMapIterator = hashTagMap.entrySet().iterator();

		while (hashTagMapIterator.hasNext()) {
			HashTag hashTag = hashTagMapIterator.next().getValue();
			if (hashTag != null) {
				hashTagList.add(hashTag);
			}
		}

		return hashTagList;
	}

	public ArrayList<HashTag> createPointsForAllHashTags(ArrayList<HashTag> hashTagList) {
		ArrayList<HashTag> newHashTagList = new ArrayList<HashTag>();
		for (HashTag hashTag : hashTagList) {
			hashTag.setHashTagPoint(new Point(hashTag.getTFVector()));
			newHashTagList.add(hashTag);
		}
		return newHashTagList;
	}

	public ArrayList<HashTag> calculateTFForAllHashTags(ArrayList<HashTag> hashTagList,
			ArrayList<String> vocabularyVector) {
		ArrayList<HashTag> newHashTagList = new ArrayList<HashTag>();
		for (HashTag hashTag : hashTagList) {
			HashTag newHashTag = calculateTFForHashTag(hashTag, vocabularyVector);
			newHashTagList.add(newHashTag);
		}
		return newHashTagList;
	}

	private HashTag calculateTFForHashTag(HashTag hashTag, ArrayList<String> vocabularyVector) {
		ArrayList<Double> tfVector = new ArrayList<Double>();

		for (String word : vocabularyVector) {
			double amount = 0.0;

			Iterator<Entry<String, Double>> wordOccurrenceMapIterator = hashTag.getWordOccurrenceMap().entrySet()
					.iterator();
			while (wordOccurrenceMapIterator.hasNext()) {
				Entry<String, Double> entry = wordOccurrenceMapIterator.next();

				String key = entry.getKey();
				Double value = entry.getValue();

				if (word.equalsIgnoreCase(key)) {
					amount = value;
				}
			}
			tfVector.add(amount);
		}

		hashTag.setTFVector(tfVector);
		return hashTag;
	}

	public ArrayList<HashTag> normalizeTFVectorForAllHashTags(ArrayList<HashTag> hashTagList) {
		ArrayList<HashTag> newHashTagList = new ArrayList<HashTag>();
		for (HashTag hashTag : hashTagList) {
			ArrayList<Double> tfVector = hashTag.getTFVector();
			ArrayList<Double> newTFVector = normalizeVector(tfVector);
			hashTag.setTFVector(newTFVector);
			newHashTagList.add(hashTag);
		}
		return newHashTagList;
	}

	public ArrayList<Double> calculateIDFForVocabularyVector(ArrayList<String> vocabularyVector,
			HashMap<String, Double> dictionary, ArrayList<HashTag> hashTagList) {
		ArrayList<Double> iDFvocabularyVector = new ArrayList<Double>();
		double hashTagAmount = hashTagList.size();
		for (String word : vocabularyVector) {
			Double amount = getHashTagAmountContainingWord(hashTagList, word);
			iDFvocabularyVector.add(Math.log(hashTagAmount / amount));
		}
		return iDFvocabularyVector;
	}

	public double getHashTagAmountContainingWord(ArrayList<HashTag> hashTagList, String word) {
		double amount = 0.0;
		for (HashTag hashTag : hashTagList) {
			Set<String> words = hashTag.getWordOccurrenceMap().keySet();
			if (words.contains(word)) {
				amount += 1.0;
			}
		}
		return amount;
	}

	private ArrayList<Double> normalizeVector(ArrayList<Double> vector) {
		ArrayList<Double> normalizedVector = new ArrayList<Double>();
		double squareVectorSum = 0.0;
		for (double i : vector) {
			squareVectorSum += i * i;
		}

		double normFactor = Math.sqrt(squareVectorSum);

		for (double i : vector) {
			double normElement = i / normFactor;
			normalizedVector.add(normElement);
		}

		return normalizedVector;
	}

	public ArrayList<HashTag> scaleVectorForAllHashTags(ArrayList<HashTag> hashTagList, ArrayList<Double> idfMatrix) {
		// TODO
		double scalar = 0;
		for (HashTag hashTag : hashTagList) {
			ArrayList<Double> scaledTFVector = hashTag.getTFVector();
			scaledTFVector = scaleVector(scaledTFVector, scalar);
		}
		return hashTagList;
	}

	private ArrayList<Double> scaleVector(ArrayList<Double> vector, double scalar) {
		ArrayList<Double> scaledVector = new ArrayList<Double>();
		for (double element : vector) {
			scaledVector.add(element * scalar);
		}
		return scaledVector;
	}

	public ArrayList<HashTag> calculateCosSimForAllHashTags(ArrayList<HashTag> hashTagList) {
		ArrayList<HashTag> newHashTagList = new ArrayList<HashTag>();
		for (HashTag hashTag : hashTagList) {
			for (HashTag hashTagCmp : hashTagList) {
				if (!hashTag.getHashTagName().equals(hashTagCmp.getHashTagName())) {
					double cosSim = cosineSimilarity(hashTag.getTFVector(), hashTagCmp.getTFVector());
					hashTag.addToCosSimHashTagMap(hashTagCmp.getHashTagName(), cosSim);
					hashTagCmp.addToCosSimHashTagMap(hashTag.getHashTagName(), cosSim);
				}
			}
			newHashTagList.add(hashTag);
		}
		return newHashTagList;
	}

	public static double cosineSimilarity(ArrayList<Double> hashTagTFVector, ArrayList<Double> hashTagTFVectorCmp) {
		double dotProduct = 0;
		double productHashTagTFVector = 0;
		double productHashTagTFVectorCmp = 0;
		for (int i = 0; i < hashTagTFVector.size(); i++) {
			dotProduct += hashTagTFVector.get(i) * hashTagTFVectorCmp.get(i);
			productHashTagTFVector += hashTagTFVector.get(i) * hashTagTFVector.get(i);
			;
			productHashTagTFVectorCmp += hashTagTFVectorCmp.get(i) * hashTagTFVectorCmp.get(i);
			;
		}
		return dotProduct / Math.sqrt(productHashTagTFVector * productHashTagTFVectorCmp);
	}

	/*
	 * Private methods
	 */
	private String cleanString(String string) {
		string = string.replaceAll("[\\.\\^\\:\\,\\;\\�\\-\\!\\?]", "");
		return string;
	}

	private boolean isMention(String string) {
		boolean isMention = false;
		if (string.startsWith("@")) {
			isMention = true;
		}
		return isMention;
	}

	private boolean isLink(String string, ArrayList<String> linkList) {
		boolean isLink = false;
		if (linkList.contains(string) || string.startsWith("http")) {
			isLink = true;
		}
		return isLink;
	}
}
