function getData() {

  var data = parseData();

  var dataBar = [{data:data.counter, color:"yellow"}];
  console.log(data.date);
  var optionsBar = {
    series: {
      bars: {
        show: true,
        width: 0.5
      }
    },
    xaxis: {
      ticks:  data.date
    }
};
  $.plot($("#barchartInput"), dataBar, optionsBar);
}
