import psycopg2
import json



try:
  connection = psycopg2.connect(
    dbname="Election", user="admin", password="admin")
  cursor = connection.cursor()
  cursor.execute("""SELECT Hashtag.hashtag, Tweet.created FROM Hashtag, Tweet WHERE Hashtag.idcontent = Tweet.id""")
  columns = ('hashtag', 'month')
  results = []

  #print str(cursor.fetchone()[1])[6]
  for row in cursor.fetchall():
      results.append({"month" : int(str(row[1])[6]), "hashtag" : row[0]})

  #print results


  with open('all_data.json','wb') as outfile:
      json.dump(results, outfile)
  print "Working till here"

except: "Not working"
