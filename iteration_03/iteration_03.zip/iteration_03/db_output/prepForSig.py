# -*- coding: utf-8 -*-
import ast
import json
import sjo
import random
import clearLine

freadPath = "hashtags.json"
fread = open(freadPath, 'r')

newNodes = "sigma_dataB.json"
fnodes = open(newNodes, 'w')
fnodes.write('{\n\t\"nodes\": [\n')
fnodes.close()
fnodes = open(newNodes, 'a')

i = j = k = m = n = p = z = 0


content = fread.readlines()
content = [x.strip() for x in content]
hashtags = []

for element in content:
    # element[i] = element[i].replace('\'', '')
    array_element = element.split( "," )
    # print(array_element)
    hashtagID = array_element[0]
    hashtagID = hashtagID.replace( '{"id":', '' )
    hashtagContendID = array_element[1]
    hashtagContendID = hashtagContendID.replace( '"idcontent":', '' )
    hashtagContent = array_element[2]
    hashtagContent = hashtagContent.replace( '"hashtag":', '' )
    hashtagContent = hashtagContent.replace( '}', '' )
    array_hashtag = [ hashtagID, hashtagContendID, hashtagContent ]
    hashtags.append( array_hashtag )

print(hashtags)

hashList = hashtags
edgeLists = []

for _ in hashList:
    edgeList = []
    _ID = _[ 0 ]
    _CID = _[ 1 ]
    _Hash = _[ 2 ]
    edgeList.extend( [ _ID, _Hash , _CID ] )
    for __ in hashList:
        __CID = __[ 1 ]
        __Hash = __[ 2 ]
        if _Hash == __Hash:
            edgeList.append( __CID )
            hashList.remove( __ )
    edgeLists.append( edgeList )

print(hashList)
print(edgeLists)

for el in edgeLists:
    elID = el[ 0 ]
    elHash = el[ 1 ]
    elLen = int( len( el ) ) - 2
    fnodes.write(
        sjo.nodeId + str( el[ 0 ] ) +
        sjo.nodeLabel + elHash +
        sjo.nodeX + str( random.randint( 0, 99 ) ) +
        sjo.nodeY + str( random.randint( 0, 99 ) ) +
        sjo.nodeSize + str( elLen ) +
        sjo.endNode )
    i = i + 1

clearLine.clearLastLine( fnodes, newNodes)
fnodes = open(newNodes, 'a')
fnodes.write('\t\t}\n],\n\t\"edges\": [\n')

for el in edgeLists:
    for el_ in el[ 2::1 ]:
        j = j + 1
        storeOld = el_
        for ele in edgeLists[ ::1 ]:
            for el__ in ele[ 2::1 ]:
                storeNew = el__
                if el_ == el__ and el[ 0 ] != ele[ 0 ]:
                    fnodes.write(
                        sjo.edgeId + str(k) +
                        sjo.edgeSource + str( el[ 0 ] ) +
                        sjo.edgeTarget + str( ele[ 0 ] ) +
                        sjo.endEdge)
                    k = k + 1

clearLine.clearLastLine( fnodes, newNodes)
fnodes = open(newNodes, 'a')
fnodes.write('\t\t}\n\t]\n}')

fnodes.close()
fread.close()

print( 'FILE IS PREPARED FOR SIGMA.JS' )
