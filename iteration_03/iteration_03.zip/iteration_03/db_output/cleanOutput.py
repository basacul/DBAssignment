import json
import ast

fname = "hashtags.json"
f = open('result.json', 'w')

with open(fname) as f:
    # for line in f:
    #     json.dumps(line)
    #     print(line)
    content = f.readlines()
    print(content)
# you may also want to remove whitespace characters like `\n` at the end of each line
content = [x.strip() for x in content]
content = ', '.join([str(x) for x in content])


# print content
f = open('result.json', 'w')
f.write("var hashtags = { \"array\": [\n")
f.write(content)
# for item in content:
#     f.write("%s\n" %item)

f.write("]\n}")
f.close()
mynewlist = [str(s) for s in content if s.isdigit()]
# print mynewlist
# for x in content


# print content
#
# a =  content
# d = {}
# for small_dict in a:
#     d.update(small_dict)
# print(d) # Yay!
# a = [d]
