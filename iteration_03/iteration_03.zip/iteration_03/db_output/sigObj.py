nodeId = '\t\t{\n\t\t\"id\": \"n'
nodeLabel = '\",\n\t\t\"label\": '
nodeX = ',\n\t\t\"x\":'
nodeY = ',\n\t\t\"y\":'
nodeSize = ',\n\t\t\"size\": '

edgeId = '\t\t{\n\t\t\"id\": \"e'
edgeSource = '\",\n\t\t\"source\": \"n'
edgeTarget = '\",\n\t\t\"target\": \"n'

endObj = '\n\t\t},\n'
