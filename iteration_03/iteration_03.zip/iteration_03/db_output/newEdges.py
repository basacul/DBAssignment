# -*- coding: utf-8 -*-
import json
import ast

fread = "hashtags.json"
fread = open(fread, 'r')

newNodes = "newNodes.json"
fnodes = open(newNodes, 'w')
fnodes.write('{\n\t\"nodes\": [\n')
fnodes.close()
fnodes = open(newNodes, 'a')

i = 0
j = 0

for line in fread:
    line = line.strip()
    array_line = line.split(",")
    array_line[2] = array_line[2].replace('"hashtag":', "")
    array_line[2] = array_line[2].replace('}', "")
    fnodes.write('\t\t{\n\t\t\"id\": \"n'+str(i)+'\",\n\t\t\"label\": '+array_line[2]+',\n\t\t\"x\":'+str(i)+',\n\t\t\"y\":'+str(i+1)+',\n\t\t\"size\": 1\n\t\t},\n')
    i = i+1
fnodes.write('\n \t],')

fnodes.close()
fread.close()
